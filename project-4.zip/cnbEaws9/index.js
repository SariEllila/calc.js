function calc(nr1, nr2, operator)
{
    let result;
    
    if (operator === "+")
    {
        result = nr1 + nr2;
    }
    else if (operator === "-")
    {
        result = nr1 - nr2;
    }
     else if (operator === "*")
    {
        result = nr1 * nr2;
    }
      else if (operator === "/")
    {
        result = nr1 / nr2;
    }
    
    return result;
}

const calcResult = calc(3, 10, "+");
console.log(calcResult);

const calcResult2 = calc(4, 12, "-");
console.log(calcResult2);

const calcResult3 = calc(10, 2, "*");
console.log(calcResult3);

const calcResult4 = calc(12, 6, "/");
console.log(calcResult4);





